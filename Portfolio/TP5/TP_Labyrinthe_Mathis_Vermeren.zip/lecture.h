#ifndef __CONST__
#define __CONST__

int load(char* filePath,int tab[TAILLE_X][TAILLE_Y], int depart[2], int arrivee[2]);


#endif
